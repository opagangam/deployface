from fastapi import FastAPI
from routers import analyze,reuslts

app = FastAPI()

# Include routers
app.include_router(analyze.router)
app.include_router(reuslts.router)
