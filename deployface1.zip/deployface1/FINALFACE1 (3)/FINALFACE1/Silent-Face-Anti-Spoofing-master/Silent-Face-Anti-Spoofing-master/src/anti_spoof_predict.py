import os
import cv2
import math
import torch
import numpy as np
import torch.nn.functional as F

from src.model_lib.MiniFASNet import MiniFASNetV1, MiniFASNetV2, MiniFASNetV1SE, MiniFASNetV2SE
from src.data_io import transform as trans
from src.utility import get_kernel, parse_model_name

MODEL_MAPPING = {
    'MiniFASNetV1': MiniFASNetV1,
    'MiniFASNetV2': MiniFASNetV2,
    'MiniFASNetV1SE': MiniFASNetV1SE,
    'MiniFASNetV2SE': MiniFASNetV2SE
}

class Detection:
    def __init__(self):
        # Get the directory where this script is located
        current_dir = os.path.dirname(os.path.abspath(__file__))
        detection_model_dir = os.path.join(current_dir, "..", "resources", "detection_model")

        # Build full paths to model files
        deploy = os.path.join(detection_model_dir, "deploy.prototxt")
        caffemodel = os.path.join(detection_model_dir, "Widerface-RetinaFace.caffemodel")

        # Ensure paths are normalized (clean backslashes, etc.)
        deploy = os.path.normpath(deploy)
        caffemodel = os.path.normpath(caffemodel)

        # Load the model
        self.detector = cv2.dnn.readNetFromCaffe(deploy, caffemodel)
        self.detector_confidence = 0.6

    def get_bboxes(self, img):
        height, width = img.shape[0], img.shape[1]
        aspect_ratio = width / height
        if img.shape[1] * img.shape[0] >= 192 * 192:
            img = cv2.resize(
                img,
                (int(192 * math.sqrt(aspect_ratio)), int(192 / math.sqrt(aspect_ratio))),
                interpolation=cv2.INTER_LINEAR
            )

        blob = cv2.dnn.blobFromImage(img, 1, mean=(104, 117, 123))
        self.detector.setInput(blob, 'data')
        out = self.detector.forward('detection_out').squeeze()
        bboxes = []
        for i in range(out.shape[0]):
            confidence = out[i, 2]
            if confidence > self.detector_confidence:
                left, top, right, bottom = out[i, 3] * width, out[i, 4] * height, out[i, 5] * width, out[i, 6] * height
                bboxes.append([int(left), int(top), int(right - left + 1), int(bottom - top + 1)])
        return bboxes


class AntiSpoofPredict(Detection):
    def __init__(self, device_id):
        super(AntiSpoofPredict, self).__init__()
        self.device = torch.device(f"cuda:{device_id}" if torch.cuda.is_available() else "cpu")

    def _load_model(self, model_path, return_model=False):
        model_name = os.path.basename(model_path)
        h_input, w_input, model_type, _ = parse_model_name(model_name)
        kernel_size = get_kernel(h_input, w_input)
        model_class = MODEL_MAPPING[model_type]
        model = model_class(conv6_kernel=kernel_size).to(self.device)

        # Load weights
        state_dict = torch.load(model_path, map_location=self.device)
        if list(state_dict.keys())[0].startswith('module.'):
            from collections import OrderedDict
            new_state_dict = OrderedDict()
            for key, value in state_dict.items():
                new_state_dict[key[7:]] = value
            model.load_state_dict(new_state_dict)
        else:
            model.load_state_dict(state_dict)

        model.eval()

        if return_model:
            return model
        else:
            self.model = model
            return None

    def predict(self, img, model_path):
        test_transform = trans.Compose([trans.ToTensor()])
        img = test_transform(img).unsqueeze(0).to(self.device)
        self._load_model(model_path)
        with torch.no_grad():
            result = self.model(img)
            result = F.softmax(result, dim=1).cpu().numpy()
        return result

    def predict_loaded(self, img, model):
        test_transform = trans.Compose([trans.ToTensor()])
        img = test_transform(img).unsqueeze(0).to(self.device)
        with torch.no_grad():
            result = model(img)
            result = F.softmax(result, dim=1).cpu().numpy()
        return result



