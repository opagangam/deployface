from typing import Optional
from fastapi import UploadFile, File

async def get_optional_file(file: Optional[UploadFile] = File(None)):
    return file
