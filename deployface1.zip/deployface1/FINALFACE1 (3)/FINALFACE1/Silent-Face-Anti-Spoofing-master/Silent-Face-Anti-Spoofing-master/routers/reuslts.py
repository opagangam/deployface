from fastapi import APIRouter
from fastapi.responses import JSONResponse
from threading import Lock

router = APIRouter()

results_lock = Lock()
last_scores = []  # You can import or manage this globally if needed

@router.get("/results")
def get_results():
    with results_lock:
        return JSONResponse(content={"results": last_scores})
