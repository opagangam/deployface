from fastapi import APIRouter, File, UploadFile, Request, Depends
from fastapi.responses import JSONResponse
from PIL import Image
import numpy as np
import io
import base64
import time
import os
import cv2

from typing import Optional
from dependency.dependencies import get_optional_file
from src.anti_spoof_predict import AntiSpoofPredict
from src.generate_patches import CropImage
from src.utility import parse_model_name

router = APIRouter()


# Automatically get the base directory where this script resides
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Device configuration
device_id = 'cpu'

# Construct dynamic paths
model_dir = os.path.normpath(os.path.join(BASE_DIR, "..", "resources", "anti_spoof_models"))
dataset_base_path = os.path.normpath(os.path.join(BASE_DIR, "..", "datasets", "rgb_image", "1_80x80"))


model_test = AntiSpoofPredict(device_id)
image_cropper = CropImage()
loaded_models = {}
for model_name in os.listdir(model_dir):
    model_path = os.path.join(model_dir, model_name)
    loaded_model = model_test._load_model(model_path, return_model=True)
    if loaded_model:
        loaded_models[model_name] = loaded_model

target_height = 400
target_width = 300

def check_image(image):
    height, width, _ = image.shape
    return abs((width / height) - (3 / 4)) <= 0.01

def save_cropped_face(img, label):
    save_dir = os.path.join(dataset_base_path, str(label))
    os.makedirs(save_dir, exist_ok=True)

    max_images = 2000
    all_images = sorted(
        [os.path.join(save_dir, f) for f in os.listdir(save_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))],
        key=lambda x: os.path.getctime(x)
    )

    if len(all_images) >= max_images:
        for file_path in all_images[:len(all_images) - max_images + 1]:
            try:
                os.remove(file_path)
            except Exception as e:
                print(f"Failed to delete {file_path}: {e}")

    filename = f"{int(time.time() * 1000)}.jpg"
    cv2.imwrite(os.path.join(save_dir, filename), img)

@router.post("/analyze_image")
async def analyze_image(request: Request, file: Optional[UploadFile] = Depends(get_optional_file)):
    try:
        if file:
            contents = await file.read()
            image = Image.open(io.BytesIO(contents)).convert("RGB")
        else:
            body = await request.json()
            if "image_base64" not in body:
                return JSONResponse(status_code=400, content={"error": "No file or base64 image provided."})

            image_data = body["image_base64"].split(",")[-1]
            image = Image.open(io.BytesIO(base64.b64decode(image_data))).convert("RGB")

        frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)

    except Exception as e:
        return JSONResponse(status_code=400, content={"error": f"Invalid image: {e}"})

    frame_resized = cv2.resize(frame, (target_width, target_height))

    if not check_image(frame_resized):
        return JSONResponse(status_code=400, content={"error": "Image aspect ratio must be approximately 3:4"})

    bboxes = model_test.get_bboxes(frame_resized)
    if not bboxes:
        return {"label": "No Face Detected", "score": 0.0}

    bbox = bboxes[0]
    prediction = np.zeros((1, 3))

    for model_name, loaded_model in loaded_models.items():
        h_input, w_input, model_type, scale = parse_model_name(model_name)
        param = {
            "org_img": frame_resized,
            "bbox": bbox,
            "scale": scale,
            "out_w": w_input,
            "out_h": h_input,
            "crop": scale is not None,
        }
        img = image_cropper.crop(**param)
        prediction += model_test.predict_loaded(img, loaded_model)

    label = np.argmax(prediction)
    value = round(prediction[0][label] / 2, 2)
    label_text = "Real" if label == 1 else "Fake"

    if label == 1 and value > 0.85:
        save_cropped_face(img, label)

    return JSONResponse(content={
        "label": label_text,
        "score": value,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    })
