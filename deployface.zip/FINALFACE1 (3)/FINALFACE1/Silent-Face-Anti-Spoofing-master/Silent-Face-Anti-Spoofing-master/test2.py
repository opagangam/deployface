import cv2
import time
import json
import numpy as np
import os
import io
import base64
from PIL import Image

from threading import Lock
from fastapi import FastAPI, File, UploadFile, Request, Depends
from typing import Optional
from fastapi.responses import JSONResponse
from src.anti_spoof_predict import AntiSpoofPredict
from src.generate_patches import CropImage
from src.utility import parse_model_name
 
app = FastAPI()
 
# === Configuration ===
device_id = 'cpu'
model_dir = r"C:\FINALFACE1\Silent-Face-Anti-Spoofing-master\Silent-Face-Anti-Spoofing-master\resources\anti_spoof_models"
model_path = os.path.join(model_dir, "2.7_80x80_MiniFASNetV2.pth")
dataset_base_path = r"C:\FINALFACE1\Silent-Face-Anti-Spoofing-master\Silent-Face-Anti-Spoofing-master\datasets\rgb_image\1_80x80"
 
# === Load Model ===
model_test = AntiSpoofPredict(device_id)
model_test._load_model(model_path)
image_cropper = CropImage()
 
# === Resize Parameters ===
target_height = 400
target_width = 300
 
# === Global Score Storage ===

last_scores = []          # For API response
prediction_lock = Lock()
results_lock = Lock()
 
# === Helpers ===
def check_image(image):
    height, width, _ = image.shape
    return abs((width / height) - (3 / 4)) <= 0.01
 
def save_cropped_face(img, label):
    save_dir = os.path.join(dataset_base_path, str(label))
    os.makedirs(save_dir, exist_ok=True)
 
    # --- Maintain only 2000 most recent images ---
    max_images = 2000
    all_images = sorted(
        [os.path.join(save_dir, f) for f in os.listdir(save_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))],
        key=lambda x: os.path.getctime(x)  # sort by creation time
    )
 
    if len(all_images) >= max_images:
        num_to_delete = len(all_images) - max_images + 1  # Make room for new image
        for file_path in all_images[:num_to_delete]:
            try:
                os.remove(file_path)
            except Exception as e:
                print(f"Failed to delete {file_path}: {e}")
 
    # --- Save new image ---
    timestamp = int(time.time() * 1000)
    filename = f"{timestamp}.jpg"
    filepath = os.path.join(save_dir, filename)
    cv2.imwrite(filepath, img)
 
 


async def get_optional_file(file: Optional[UploadFile] = File(None)):
    return file
@app.post("/analyze_image")
async def analyze_image(request: Request, file: Optional[UploadFile] = Depends(get_optional_file)):
    try:
        if file:
            # Case 1: Uploaded file
            contents = await file.read()
            image = Image.open(io.BytesIO(contents)).convert("RGB")
        else:
            # Case 2: base64 in JSON body
            body = await request.json()
            if "image_base64" not in body:
                return JSONResponse(status_code=400, content={"error": "No file or base64 image provided."})
           
            image_data = body["image_base64"]
            if "," in image_data:
                image_data = image_data.split(",")[1]
           
            decoded_bytes = base64.b64decode(image_data)
            image = Image.open(io.BytesIO(decoded_bytes)).convert("RGB")
 
        frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
 
    except Exception as e:
        return JSONResponse(status_code=400, content={"error": f"Invalid image: {e}"})
 
    frame_resized = cv2.resize(frame, (target_width, target_height))
 
    if not check_image(frame_resized):
        return JSONResponse(status_code=400, content={"error": "Image aspect ratio must be approximately 3:4"})
 
    bboxes = model_test.get_bboxes(frame_resized)
    if not bboxes:
        return {"label": "No Face Detected", "score": 0.0}
 
    bbox = bboxes[0]
    prediction = np.zeros((1, 3))
 
    for model_name in os.listdir(model_dir):
        h_input, w_input, model_type, scale = parse_model_name(model_name)
        param = {
            "org_img": frame_resized,
            "bbox": bbox,
            "scale": scale,
            "out_w": w_input,
            "out_h": h_input,
            "crop": True,
        }
        if scale is None:
            param["crop"] = False
        img = image_cropper.crop(**param)
        prediction += model_test.predict(img, os.path.join(model_dir, model_name))
 
    label = np.argmax(prediction)
    value = round(prediction[0][label] / 2, 2)
    label_text = "Real" if label == 1 else "Fake"
 
    # Save cropped image if prediction is "Real" and confident
    if label == 1 and value > 0.85:
        save_cropped_face(img, label)
 
    result = {
        "label": label_text,
        "score": value,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    }
 
    return JSONResponse(content=result)
 
 

 
@app.get("/results")
def get_results():
    with results_lock:
        return JSONResponse(content={"results": last_scores})