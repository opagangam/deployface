import cv2
import time
import numpy as np
import os
from fastapi import FastAPI, Response
from fastapi.responses import StreamingResponse
from src.anti_spoof_predict import AntiSpoofPredict
from src.generate_patches import CropImage
from src.utility import parse_model_name

app = FastAPI()

# Initialize model and cropper globally so it loads once
device_id = 'cpu'
model_dir = r"C:\FINALFACE1\Silent-Face-Anti-Spoofing-master\resources\anti_spoof_models"
model_path = r"C:\FINALFACE1\Silent-Face-Anti-Spoofing-master\Silent-Face-Anti-Spoofing-master\resources\anti_spoof_models\2.7_80x80_MiniFASNetV2.pth"

model_test = AntiSpoofPredict(device_id)
model_test._load_model(model_path)
image_cropper = CropImage()

target_height = 400
target_width = 300

def check_image(image):
    height, width, channel = image.shape
    if abs((width / height) - (3 / 4)) > 0.01:
        return False
    return True

def process_frame(frame):
    frame_resized = cv2.resize(frame, (target_width, target_height))
    if not check_image(frame_resized):
        return frame_resized

    bboxes = model_test.get_bboxes(frame_resized)

    for bbox in bboxes:
        prediction = np.zeros((1, 3))
        for model_name in os.listdir(model_dir):
            h_input, w_input, model_type, scale = parse_model_name(model_name)
            param = {
                "org_img": frame_resized,
                "bbox": bbox,
                "scale": scale,
                "out_w": w_input,
                "out_h": h_input,
                "crop": True,
            }
            if scale is None:
                param["crop"] = False
            img = image_cropper.crop(**param)
            prediction += model_test.predict(img, os.path.join(model_dir, model_name))

        label = np.argmax(prediction)
        value = prediction[0][label] / 2

        if label == 1:
            result_text = f"RealFace Score: {value:.2f}"
            color = (255, 0, 0)
        else:
            result_text = f"FakeFace Score: {value:.2f}"
            color = (0, 0, 255)

        cv2.rectangle(frame_resized, (bbox[0], bbox[1]), (bbox[0]+bbox[2], bbox[1]+bbox[3]), color, 2)
        cv2.putText(frame_resized, result_text, (bbox[0], bbox[1]-10),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

    return frame_resized

def gen_frames():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        processed_frame = process_frame(frame)

        # Encode the frame in JPEG format
        ret, buffer = cv2.imencode('.jpg', processed_frame)
        if not ret:
            continue

        frame_bytes = buffer.tobytes()

        # Yield frame in multipart format for streaming
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

    cap.release()

@app.get('/video_feed')
def video_feed():
    return StreamingResponse(gen_frames(), media_type='multipart/x-mixed-replace; boundary=frame')
