import cv2
import time
import json
import numpy as np
import os
import io
import base64
from PIL import Image

from threading import Lock
from fastapi import FastAPI, File, UploadFile, Request, Depends
from typing import Optional
from fastapi.responses import JSONResponse
from src.anti_spoof_predict import AntiSpoofPredict
from src.generate_patches import CropImage
from src.utility import parse_model_name
 
app = FastAPI()
 
# === Configuration ===
device_id = 'cpu'
model_dir = r"C:\FINALFACE1\Silent-Face-Anti-Spoofing-master\Silent-Face-Anti-Spoofing-master\resources\anti_spoof_models"
model_path = os.path.join(model_dir, "2.7_80x80_MiniFASNetV2.pth")
dataset_base_path = r"C:\FINALFACE1\Silent-Face-Anti-Spoofing-master\Silent-Face-Anti-Spoofing-master\datasets\rgb_image\1_80x80"
 
# === Load Model ===
model_test = AntiSpoofPredict(device_id)
model_test._load_model(model_path)
image_cropper = CropImage()
 
# === Resize Parameters ===
target_height = 400
target_width = 300
 
# === Global Score Storage ===

last_scores = []          # For API response
prediction_lock = Lock()
results_lock = Lock()
 
# === Helpers ===
def check_image(image):
    height, width, _ = image.shape
    return abs((width / height) - (3 / 4)) <= 0.01
 
def save_cropped_face(img, label):
    save_dir = os.path.join(dataset_base_path, str(label))
    os.makedirs(save_dir, exist_ok=True)
 
    # --- Maintain only 2000 most recent images ---
    max_images = 2000
    all_images = sorted(
        [os.path.join(save_dir, f) for f in os.listdir(save_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))],
        key=lambda x: os.path.getctime(x)  # sort by creation time
    )
 
    if len(all_images) >= max_images:
        num_to_delete = len(all_images) - max_images + 1  # Make room for new image
        for file_path in all_images[:num_to_delete]:
            try:
                os.remove(file_path)
            except Exception as e:
                print(f"Failed to delete {file_path}: {e}")
 
    # --- Save new image ---
    timestamp = int(time.time() * 1000)
    filename = f"{timestamp}.jpg"
    filepath = os.path.join(save_dir, filename)
    cv2.imwrite(filepath, img)
 
 


async def get_optional_file(file: Optional[UploadFile] = File(None)):
    return file
@app.post("/analyze_image")
async def analyze_image(request: Request, file: Optional[UploadFile] = Depends(get_optional_file)):
    try:
        if file:
            # Case 1: Uploaded file
            contents = await file.read()
            image = Image.open(io.BytesIO(contents)).convert("RGB")
        else:
            # Case 2: base64 in JSON body
            body = await request.json()
            if "image_base64" not in body:
                return JSONResponse(status_code=400, content={"error": "No file or base64 image provided."})
           
            image_data = body["image_base64"]
            if "," in image_data:
                image_data = image_data.split(",")[1]
           
            decoded_bytes = base64.b64decode(image_data)
            image = Image.open(io.BytesIO(decoded_bytes)).convert("RGB")
 
        frame = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
 
    except Exception as e:
        return JSONResponse(status_code=400, content={"error": f"Invalid image: {e}"})
 
    frame_resized = cv2.resize(frame, (target_width, target_height))
 
    if not check_image(frame_resized):
        return JSONResponse(status_code=400, content={"error": "Image aspect ratio must be approximately 3:4"})
 
    bboxes = model_test.get_bboxes(frame_resized)
    if not bboxes:
        return {"label": "No Face Detected", "score": 0.0}
 
    bbox = bboxes[0]
    prediction = np.zeros((1, 3))
 
    for model_name in os.listdir(model_dir):
        h_input, w_input, model_type, scale = parse_model_name(model_name)
        param = {
            "org_img": frame_resized,
            "bbox": bbox,
            "scale": scale,
            "out_w": w_input,
            "out_h": h_input,
            "crop": True,
        }
        if scale is None:
            param["crop"] = False
        img = image_cropper.crop(**param)
        prediction += model_test.predict(img, os.path.join(model_dir, model_name))
 
    label = np.argmax(prediction)
    value = round(prediction[0][label] / 2, 2)
    label_text = "Real" if label == 1 else "Fake"
 
    # Save cropped image if prediction is "Real" and confident
    if label == 1 and value > 0.85:
        save_cropped_face(img, label)
 
    result = {
        "label": label_text,
        "score": value,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    }
 
    return JSONResponse(content=result)
 
 

 
@app.get("/results")
def get_results():
    with results_lock:
        return JSONResponse(content={"results": last_scores})


#def process_frame(frame):
#     global accumulated_scores
#     frame_resized = cv2.resize(frame, (target_width, target_height))
#     if not check_image(frame_resized):
#         return frame_resized
 
#     bboxes = model_test.get_bboxes(frame_resized)
#     if not bboxes:
#         print("No face detected.")
#         # Optionally, append this to scores so it's visible in API response
#         score_entry = {
#             "label": "No Face Detected",
#             "score": 0.0,
#             "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
#         }
#         with prediction_lock:
#             accumulated_scores.append(score_entry)
 
#         return frame_resized
 
#     for bbox in bboxes:
#         prediction = np.zeros((1, 3))
#         for model_name in os.listdir(model_dir):
#             h_input, w_input, model_type, scale = parse_model_name(model_name)
#             param = {
#                 "org_img": frame_resized,
#                 "bbox": bbox,
#                 "scale": scale,
#                 "out_w": w_input,
#                 "out_h": h_input,
#                 "crop": True,
#             }
#             if scale is None:
#                 param["crop"] = False
#             img = image_cropper.crop(**param)
#             prediction += model_test.predict(img, os.path.join(model_dir, model_name))
 
#         label = np.argmax(prediction)
#         value = prediction[0][label] / 2  # Confidence
 
#         # Save high-confidence cropped face
#         if label==1 and value > 0.85:
#             save_cropped_face(img, label)
 
#         label_text = "Real" if label == 1 else "Fake"
#         result_text = f"{label_text}Face Score: {value:.2f}"
#         color = (255, 0, 0) if label == 1 else (0, 0, 255)
 
#         cv2.rectangle(frame_resized, (bbox[0], bbox[1]), (bbox[0]+bbox[2], bbox[1]+bbox[3]), color, 2)
#         cv2.putText(frame_resized, result_text, (bbox[0], bbox[1]-10),
#                     cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
 
#         # Save scores for API and console
#         score_entry = {
#             "label": label_text,
#             "score": round(float(value), 2),
#             "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
 
#         }
 
#         with prediction_lock:
#             accumulated_scores.append(score_entry)
 
#     return frame_resized









#threading.Thread(target=reset_and_report_scores, daemon=True).start()
# def generate_live_scores():
#     last_reported = 0
#     while True:
#         time.sleep(10)
#         with results_lock:
#             if last_scores and len(last_scores) > last_reported:
#                 # Take only new scores since last_reported
#                 new_scores = last_scores[last_reported:]
#                 last_reported = len(last_scores)
#                 yield f"data: {json.dumps({'results': new_scores})}\n\n"
#             else:
#                 # Still yield something to keep connection alive
#                 yield f"data: {json.dumps({'results': []})}\n\n"

#def gen_frames():
#     cap = cv2.VideoCapture(0)
#     if not cap.isOpened():
#         print("Error: Could not open webcam.")
#         return
#     start_time=time.time()
#     duration=15
 
#     while True:
#         if time.time()-start_time>duration:
#             break
 
#         ret, frame = cap.read()
#         if not ret:
#             break
 
#         processed_frame = process_frame(frame)
 
#         ret, buffer = cv2.imencode('.jpg', processed_frame)
#         if not ret:
#             continue
 
#         frame_bytes = buffer.tobytes()
#         yield (b'--frame\r\n'
#                b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')
 
#     cap.release()

# def reset_and_report_scores():
#     global accumulated_scores, last_scores
#     while True:
#         time.sleep(10)
#         with prediction_lock:
#             scores_to_report = accumulated_scores.copy()
#             accumulated_scores.clear()
 
#         real_count = sum(1 for score in scores_to_report if score["label"] == "Real")
#         fake_count = sum(1 for score in scores_to_report if score["label"] == "Fake")
 
#         if real_count == 0 and fake_count == 0:
#             final_label = "No Face Detected"
#             final_score = 0.0
#         elif real_count >= fake_count:
#             final_label = "Real"
#             final_score = round(real_count / (real_count + fake_count), 2)
#         else:
#             final_label = "Fake"
#             final_score = round(fake_count / (real_count + fake_count), 2)
 
#         aggregated_result = {
#             "label": final_label,
#             "score": final_score,
#             "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
#         }
 
#         with results_lock:
#             last_scores = [aggregated_result]
  

# === FastAPI Endpoints ===
# @app.get('/video_feed')
# def video_feed():
#     return StreamingResponse(gen_frames(), media_type='multipart/x-mixed-replace; boundary=frame')
# from fastapi import File, UploadFile
# import tempfile
 
# @app.post("/analyze_video")
# async def analyze_video(file: UploadFile = File(...)):
#     if not (file.filename.endswith(".mp4") or file.filename.endswith(".webm")):
#         return JSONResponse(content={"error": "Only .mp4 and .webp formats are supported."}, status_code=400)
 
#     # Save the uploaded file temporarily
#     with tempfile.NamedTemporaryFile(delete=False, suffix=file.filename[-4:]) as temp_file:
#         temp_file.write(await file.read())
#         temp_video_path = temp_file.name
 
#     # Initialize video capture
#     cap = cv2.VideoCapture(temp_video_path)
#     if not cap.isOpened():
#         os.remove(temp_video_path)
#         return JSONResponse(content={"error": "Failed to open video."}, status_code=500)
 
#     video_scores = []
#     frame_skip=5
#     frame_count=0
 
#     while True:
#         ret, frame = cap.read()
#         if not ret:
#             break
#         if frame_count%frame_skip!=0:
#             frame_count+=1
#             continue
#         frame_count+=1
 
#         processed_frame = process_frame(frame)
 
#         # Extract last prediction from accumulated_scores
#         with prediction_lock:
#             if accumulated_scores:
#                 score_entry = accumulated_scores[-1]
#                 video_scores.append(score_entry)
 
#     cap.release()
#     os.remove(temp_video_path)
 
#     # Aggregate results
#     real_count = sum(1 for score in video_scores if score["label"] == "Real")
#     fake_count = sum(1 for score in video_scores if score["label"] == "Fake")
 
#     if real_count == 0 and fake_count == 0:
#         final_label = "No Face Detected"
#         final_score = 0.0
#     elif real_count >= fake_count:
#         final_label = "Real"
#         final_score = round(real_count / (real_count + fake_count), 2)
#     else:
#         final_label = "Fake"
#         final_score = round(fake_count / (real_count + fake_count), 2)
 
#     result = {
#         "label": final_label,
#         "score": final_score,
#         "details": video_scores,
#         "timestamp": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
#     }
 
#     return JSONResponse(content=result)

# @app.get("/")
# def index():
#     html_content = """
#     <html>
#     <head>
#         <title>Live Webcam Anti-Spoofing</title>
#     </head>
#     <body>
#         <h1>Live Webcam Feed</h1>
#         <img src="/video_feed" width="600" />
#         <p>Faces with confidence > 0.85 are saved.<br/>
#         Every 10 seconds, prediction scores are printed to the console.</p>
#     </body>
#     </html>
#     """
#     return HTMLResponse(content=html_content)