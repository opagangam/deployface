import torch
from src.model_lib.MultiFTNet import MultiFTNet  # adjust import path if needed

def check_checkpoint_compatibility(checkpoint_path, model_conf, device='cpu'):
    # Initialize your model with the given config
    model = MultiFTNet(
        num_classes=model_conf.num_classes,
        img_channel=model_conf.input_channel,
        embedding_size=model_conf.embedding_size,
        conv6_kernel=model_conf.kernel_size
    ).to(device)

    # Load checkpoint state dict
    checkpoint = torch.load(checkpoint_path, map_location=device)
    if isinstance(checkpoint, dict) and 'state_dict' in checkpoint:
        state_dict = checkpoint['state_dict']  # if checkpoint has 'state_dict' key
    else:
        state_dict = checkpoint  # else assume checkpoint itself is the state_dict

    model_state_dict = model.state_dict()

    # Check keys presence
    missing_keys = []
    unexpected_keys = []
    shape_mismatches = []

    for key in model_state_dict.keys():
        if key not in state_dict:
            missing_keys.append(key)
        else:
            if model_state_dict[key].shape != state_dict[key].shape:
                shape_mismatches.append((key, model_state_dict[key].shape, state_dict[key].shape))

    for key in state_dict.keys():
        if key not in model_state_dict:
            unexpected_keys.append(key)

    print(f"Missing keys in checkpoint: {missing_keys if missing_keys else 'None'}")
    print(f"Unexpected keys in checkpoint: {unexpected_keys if unexpected_keys else 'None'}")
    print(f"Shape mismatches: {shape_mismatches if shape_mismatches else 'None'}")

    if not missing_keys and not unexpected_keys and not shape_mismatches:
        print("Checkpoint is fully compatible with the model!")
    else:
        print("Checkpoint has compatibility issues. Please check above lists.")

# Example usage:
class Conf:
    num_classes = 3
    input_channel = 3
    embedding_size = 128
    kernel_size = (5, 5)  # replace with your actual kernel size

conf = Conf()
checkpoint_path = r"C:\FINALFACE1\Silent-Face-Anti-Spoofing-master\resources\anti_spoof_models\2.7_80x80_MiniFASNetV2.pth"

check_checkpoint_compatibility(checkpoint_path, conf, device='cpu')
