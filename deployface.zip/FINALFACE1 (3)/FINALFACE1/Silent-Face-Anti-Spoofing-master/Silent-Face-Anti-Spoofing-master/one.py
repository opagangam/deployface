import face_recognition
from PIL import Image
import os
import io

def upscale_image(image_path, size=(200, 200)):
    try:
        with Image.open(image_path) as img:
            upscaled = img.resize(size, Image.LANCZOS)
            return upscaled
    except Exception as e:
        print(f"❌ Error loading image {image_path}: {e}")
        return None

def process_image(image_path):
    # Upscale to 200x200
    upscaled_image = upscale_image(image_path)
    if upscaled_image is None:
        return False, None

    # Convert to RGB and save to memory
    upscaled_image = upscaled_image.convert("RGB")
    buffer = io.BytesIO()
    upscaled_image.save(buffer, format="JPEG")
    buffer.seek(0)

    # Load image using face_recognition
    image = face_recognition.load_image_file(buffer)
    face_locations = face_recognition.face_locations(image)

    if face_locations:
        face_encoding = face_recognition.face_encodings(image)[0]  # First face only
        return True, face_encoding
    else:
        return False, None

def compare_faces(image1_path, image2_path):
    print(f"🔍 Processing: {image1_path}")
    face1_found, encoding1 = process_image(image1_path)
    print(f"🔍 Processing: {image2_path}")
    face2_found, encoding2 = process_image(image2_path)

    print("\n📋 Results:")
    print(f"Image 1 - Face found: {'✅' if face1_found else '❌'}")
    print(f"Image 2 - Face found: {'✅' if face2_found else '❌'}")

    if face1_found and face2_found:
        match_result = face_recognition.compare_faces([encoding1], encoding2)[0]
        print(f"👥 Faces match: {'✅ Yes' if match_result else '❌ No'}")
    else:
        print("⚠️ Face comparison skipped due to missing face(s).")

def load_known_faces(dataset_dir):
    known_encodings = []
    known_names = []

    for person_name in os.listdir(dataset_dir):
        person_dir = os.path.join(dataset_dir, person_name)
        if not os.path.isdir(person_dir):
            continue

        for filename in os.listdir(person_dir):
            filepath = os.path.join(person_dir, filename)
            if not os.path.isfile(filepath):
                continue

            face_found, encoding = process_image(filepath)
            if face_found:
                known_encodings.append(encoding)
                known_names.append(person_name)
    
    return known_encodings, known_names

def identify_face(input_image_path, dataset_dir):
    print(f"\n🔍 Identifying face in: {input_image_path}")
    face_found, input_encoding = process_image(input_image_path)

    if not face_found:
        print("❌ No face found in the input image.")
        return

    known_encodings, known_names = load_known_faces(dataset_dir)

    print("🧠 Comparing with known faces...")
    matches = face_recognition.compare_faces(known_encodings, input_encoding)

    if True in matches:
        matched_index = matches.index(True)
        matched_name = known_names[matched_index]
        print(f"✅ Match found: {matched_name}")
    else:
        print("❌ No match found. Person is Unknown.")

# ========== Example Usage ==========

# Part 1: Direct Image-to-Image Comparison
image1 = r"C:\FINALFACE1\Silent-Face-Anti-Spoofing-master\Silent-Face-Anti-Spoofing-master\datasets\rgb_image\1_80x80\1\1749403978766.jpg"
image2 = r"C:\FINALFACE1\Silent-Face-Anti-Spoofing-master\Silent-Face-Anti-Spoofing-master\know_faces\anirudh\WhatsApp Image 2025-06-08 at 9.57.38 PM.jpg"
compare_faces(image1, image2)

# Part 2: Identify from Dataset
dataset_path = r"C:\FINALFACE1\Silent-Face-Anti-Spoofing-master\Silent-Face-Anti-Spoofing-master\know_faces"
identify_face(image1, dataset_path)
